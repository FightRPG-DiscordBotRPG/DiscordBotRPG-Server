'use strict';
var MySql = require('sync-mysql');

var connection = new MySql({
    host: 'localhost',
    user: 'discord_bot_rpg',
    password: 'sdo#FWDViY5tgG*e',
    database: 'discord_bot_rpg'
});

module.exports = connection;

//sdo#FWDViY5tgG*e
//sdobFWDViY5tgGYe
