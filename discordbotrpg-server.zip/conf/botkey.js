'use strict';
const Key = "NDAxNDIxNjQ0OTY4NjI0MTI5.DTp9Tw.qg4fglERlOHMIebYb_zbVtScvfk";

module.exports = Key;